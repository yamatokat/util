# hello_function.py

def say_hello():
    print("Hello")

# ファイルが直接実行された場合にだけ実行されるコード
if __name__ == "__main__":
    say_hello()